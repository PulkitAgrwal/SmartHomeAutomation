package smarthome.auth;

/**
 * Security utility class to handle authentication and security-related
 * operations.
 * Demonstrates use of wrapper classes and static nested classes.
 */
public class Security {

    /**
     * Inner static class that wraps password operations.
     * Demonstrates use of wrappers and nested classes.
     */
    public static class PasswordHandler {
        /**
         * Checks password strength.
         * 
         * @param password The password to check
         * @return Boolean wrapper indicating if password is strong enough
         */
        public static Boolean isStrongPassword(String password) {
            // Password must be at least 8 characters and contain at least one digit
            return Boolean.valueOf(password.length() >= 8 && password.matches(".*\\d.*"));
        }

        /**
         * Converts password to character array for more secure handling.
         * 
         * @param password The password string
         * @return Character array representation
         */
        public static Character[] toCharArray(String password) {
            Character[] chars = new Character[password.length()];
            for (int i = 0; i < password.length(); i++) {
                chars[i] = Character.valueOf(password.charAt(i));
            }
            return chars;
        }
    }

    /**
     * Demonstrates varargs method overloading.
     * Validates multiple usernames against a pattern.
     * 
     * @param pattern   The pattern to match
     * @param usernames Variable number of usernames to validate
     * @return Number of valid usernames
     */
    public static int validateUsernames(String pattern, String... usernames) {
        int valid = 0;
        for (String username : usernames) {
            if (username.matches(pattern)) {
                valid++;
            }
        }
        return valid;
    }

    /**
     * Overloaded method that validates a single username.
     * 
     * @param pattern  The pattern to match
     * @param username The username to validate
     * @return If the username is valid
     */
    public static boolean validateUsernames(String pattern, String username) {
        return username.matches(pattern);
    }
}