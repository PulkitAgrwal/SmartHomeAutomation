package smarthome.auth;

import smarthome.devices.*;
import smarthome.automation.ScheduledAutomation;
import smarthome.io.FileHandler;
import java.util.List;
import java.util.Scanner;
import java.io.Serializable;

/**
 * Regular User - Can control devices but has limited permissions.
 * Extends the User class.
 */
public class RegularUser extends User implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for creating a regular user with username and password
     * 
     * @param username the user's username
     * @param password the user's password
     */
    public RegularUser(String username, String password) {
        super(username, password);
    }

    /**
     * Implementation of the abstract method from User class
     * 
     * @return the role as "Regular User"
     */
    @Override
    public String getRole() {
        return "Regular User";
    }

    /**
     * Login method for regular users
     * 
     * @param scanner Scanner for user input
     * @return true if login successful, false otherwise
     */
    public boolean login(Scanner scanner) {
        System.out.print("👤 Enter User Password: ");
        String inputPassword = scanner.nextLine();
        boolean success = authenticate(inputPassword);

        if (success) {
            FileHandler.logEvent("User login successful: " + this.getUsername());
            System.out.println("✅ Login successful! Welcome, " + this.getUsername() + ".");
        } else {
            System.out.println("❌ Incorrect password. Access denied.");
        }

        return success;
    }

    /**
     * Controls a device from the available devices list
     * 
     * @param scanner Scanner for user input
     * @param devices List of available devices
     */
    private void controlDevice(Scanner scanner, List<ControllableDevice> devices) {
        if (devices.isEmpty()) {
            System.out.println("⚠️ No devices available to control.");
            return;
        }

        // 1️⃣ Show available devices first
        System.out.println("\n📜 Select a Device to Control:");
        for (int i = 0; i < devices.size(); i++) {
            System.out.println("   " + i + ". " + devices.get(i).getStatus());
        }

        // 2️⃣ Ask user to choose a device
        System.out.print("💡 Enter the number of the device to control: ");
        int index;
        try {
            index = scanner.nextInt();
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌ Invalid input! Please enter a valid number.");
            scanner.nextLine();
            return;
        }

        // 3️⃣ Validate selection
        if (index < 0 || index >= devices.size()) {
            System.out.println("❌ Invalid selection. Returning to menu.");
            return;
        }

        ControllableDevice selectedDevice = devices.get(index);
        System.out.println("\n✅ You selected: " + selectedDevice.getName());

        // 4️⃣ Show control options based on device type
        if (selectedDevice instanceof Light) {
            System.out.println("1️⃣ Turn ON");
            System.out.println("2️⃣ Turn OFF");
            System.out.println("3️⃣ Adjust Brightness");
        } else if (selectedDevice instanceof Fan) {
            System.out.println("1️⃣ Turn ON");
            System.out.println("2️⃣ Turn OFF");
            System.out.println("3️⃣ Adjust Speed");
        } else if (selectedDevice instanceof AC) {
            System.out.println("1️⃣ Turn ON");
            System.out.println("2️⃣ Turn OFF");
            System.out.println("3️⃣ Adjust Temperature");
        } else {
            System.out.println("⚠️ Unknown device type.");
            return;
        }

        System.out.print("💡 Choose an action: ");
        int action;
        try {
            action = scanner.nextInt();
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌ Invalid input! Please enter a valid number.");
            scanner.nextLine();
            return;
        }

        // 5️⃣ Execute the selected action
        try {
            switch (action) {
                case 1:
                    selectedDevice.turnOn();
                    FileHandler.logEvent("User " + getUsername() + " turned ON " + selectedDevice.getName());
                    break;
                case 2:
                    selectedDevice.turnOff();
                    FileHandler.logEvent("User " + getUsername() + " turned OFF " + selectedDevice.getName());
                    break;
                case 3:
                    if (selectedDevice instanceof Light) {
                        System.out.print("💡 Enter brightness level (0-100): ");
                        int brightness = scanner.nextInt();
                        scanner.nextLine();
                        ((Light) selectedDevice).setBrightness(brightness);
                        FileHandler.logEvent("User " + getUsername() + " set brightness of " + selectedDevice.getName()
                                + " to " + brightness);
                    } else if (selectedDevice instanceof Fan) {
                        System.out.print("🌪️ Enter speed level (1-5): ");
                        int speed = scanner.nextInt();
                        scanner.nextLine();
                        ((Fan) selectedDevice).setSpeed(speed);
                        FileHandler.logEvent(
                                "User " + getUsername() + " set speed of " + selectedDevice.getName() + " to " + speed);
                    } else if (selectedDevice instanceof AC) {
                        System.out.print("❄️ Enter temperature (16-30°C): ");
                        int temp = scanner.nextInt();
                        scanner.nextLine();
                        ((AC) selectedDevice).setTemperature(temp);
                        FileHandler.logEvent("User " + getUsername() + " set temperature of " + selectedDevice.getName()
                                + " to " + temp);
                    }
                    break;
                default:
                    System.out.println("❌ Invalid action.");
            }
        } catch (Exception e) {
            System.out.println("❌ Error controlling device: " + e.getMessage());
        }
    }

    /**
     * Displays user menu and handles user actions
     * 
     * @param scanner    Scanner for user input
     * @param devices    List of available devices
     * @param automation Scheduled automation handler
     */
    public void userMenu(Scanner scanner, List<ControllableDevice> devices, ScheduledAutomation automation) {
        boolean running = true;
        while (running) {
            System.out.println("\n=============================");
            System.out.println("📌 User Menu");
            System.out.println("=============================");
            System.out.println("1️⃣ View Devices");
            System.out.println("2️⃣ Control Device");
            System.out.println("3️⃣ Schedule Automation");
            System.out.println("4️⃣ Logout");
            System.out.println("=============================");

            System.out.print("💡 Choose an option: ");
            int choice;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (Exception e) {
                System.out.println("❌ Invalid input! Please enter a number.");
                scanner.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    if (devices.isEmpty()) {
                        System.out.println("⚠️ No devices found.");
                    } else {
                        System.out.println("📜 Available Devices:");
                        for (int i = 0; i < devices.size(); i++) {
                            System.out.println("   " + i + ". " + devices.get(i).getStatus());
                        }
                    }
                    break;
                case 2:
                    controlDevice(scanner, devices);
                    break;
                case 3:
                    automation.scheduleAutomation(scanner, devices);
                    break;
                case 4:
                    running = false;
                    FileHandler.logEvent("User logged out: " + getUsername());
                    System.out.println("👋 Logging out...");
                    break;
                default:
                    System.out.println("❌ Invalid choice. Try again.");
            }
        }
    }
}