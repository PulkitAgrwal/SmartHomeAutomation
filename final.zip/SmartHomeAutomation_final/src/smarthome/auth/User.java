package smarthome.auth;

import java.io.Serializable;

/**
 * Abstract class representing a generic user.
 * Implements authentication and role-based access.
 */
public abstract class User implements Serializable {
    private static final long serialVersionUID = 1L;

    protected String username;
    protected String password; // Stored securely in real-world applications.

    /**
     * Constructor for creating a user with username and password
     * 
     * @param username the user's username
     * @param password the user's password
     */
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Authenticates the user by checking if the input password matches
     * 
     * @param inputPassword the password to check
     * @return true if password matches, false otherwise
     */
    public boolean authenticate(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    /**
     * Gets the username of the user
     * 
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Abstract method to get the role of the user.
     * Ensures role-based access control.
     * 
     * @return the role of the user
     */
    public abstract String getRole();
}