package smarthome.auth;

import smarthome.devices.*;
import smarthome.io.FileHandler;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;

/**
 * Admin class - Manages users, devices, and authentication.
 * Extends User class and implements administrative functionality.
 */
public class Admin extends User {
    private static final long serialVersionUID = 1L;

    private List<RegularUser> users;
    private List<ControllableDevice> devices;
    private int lightCount = 0, fanCount = 0, acCount = 0; // Track device counts

    /**
     * Constructor for creating an Admin with username and password
     * 
     * @param username the admin's username
     * @param password the admin's password
     */
    public Admin(String username, String password) {
        super(username, password);
        this.users = new ArrayList<>();
        this.devices = new ArrayList<>();

        // Try to load existing users
        try {
            this.users = FileHandler.loadUsers();
            if (!users.isEmpty()) {
                System.out.println("✅ Loaded " + users.size() + " users from file.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("⚠️ Could not load users: " + e.getMessage());
        }
    }

    /**
     * Overloaded constructor with varargs for initial devices
     * Demonstrates constructor overloading
     * 
     * @param username       the admin's username
     * @param password       the admin's password
     * @param initialDevices variable number of devices to initialize with
     */
    public Admin(String username, String password, ControllableDevice... initialDevices) {
        this(username, password);
        for (ControllableDevice device : initialDevices) {
            devices.add(device);
            updateDeviceCount(device);
            FileHandler.logEvent("Admin initialized with device: " + device.getName());
        }
    }

    /**
     * Helper method to update device count based on device type
     * 
     * @param device the device to count
     */
    private void updateDeviceCount(ControllableDevice device) {
        if (device instanceof Light)
            lightCount++;
        else if (device instanceof Fan)
            fanCount++;
        else if (device instanceof AC)
            acCount++;
    }

    /**
     * Implementation of abstract method from User class
     * 
     * @return the role as "Admin"
     */
    @Override
    public String getRole() {
        return "Admin";
    }

    /**
     * Admin login method that asks for username first, then password
     * 
     * @param scanner Scanner for user input
     * @return true if login successful, false otherwise
     */
    public boolean login(Scanner scanner) {
        System.out.print("👤 Enter Admin Username: ");
        String inputUsername = scanner.nextLine();
        if (!inputUsername.equals(this.getUsername())) {
            System.out.println("❌ Incorrect username.");
            return false;
        }

        System.out.print("🔒 Enter Admin Password: ");
        String inputPassword = scanner.nextLine();
        if (!authenticate(inputPassword)) {
            System.out.println("❌ Incorrect password. Access denied.");
            return false;
        }

        FileHandler.logEvent("Admin login successful: " + this.getUsername());
        System.out.println("✅ Login Successful! Welcome, Admin.");
        return true;
    }

    /**
     * Displays admin menu and handles admin actions
     * 
     * @param scanner Scanner for user input
     */
    public void adminMenu(Scanner scanner) {
        boolean running = true;
        while (running) {
            System.out.println("\n=============================");
            System.out.println("🔹 Admin Menu 🔹");
            System.out.println("=============================");
            System.out.println("1️⃣ View Users");
            System.out.println("2️⃣ Add User");
            System.out.println("3️⃣ Remove User");
            System.out.println("4️⃣ Add Device");
            System.out.println("5️⃣ Remove Device");
            System.out.println("6️⃣ View Devices");
            System.out.println("7️⃣ View Energy Consumption");
            System.out.println("8️⃣ View System Logs");
            System.out.println("9️⃣ Logout");
            System.out.println("=============================");

            System.out.print("💡 Choose an option: ");
            int choice;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (Exception e) {
                System.out.println("❌ Invalid input! Please enter a number.");
                scanner.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    viewUsers();
                    break;
                case 2:
                    addUser(scanner);
                    break;
                case 3:
                    removeUser(scanner);
                    break;
                case 4:
                    addDevice(scanner);
                    break;
                case 5:
                    removeDevice(scanner);
                    break;
                case 6:
                    viewDevices();
                    break;
                case 7:
                    viewEnergyConsumption();
                    break;
                case 8:
                    viewSystemLogs();
                    break;
                case 9:
                    System.out.println("👋 Logging out...");
                    saveUsersToFile();
                    running = false;
                    break;
                default:
                    System.out.println("❌ Invalid option. Try again.");
            }
        }
    }

    /**
     * Displays system logs from the log file
     */
    private void viewSystemLogs() {
        List<String> logs = FileHandler.readLogs();
        if (logs.isEmpty()) {
            System.out.println("⚠️ No system logs found.");
        } else {
            System.out.println("📜 System Logs (most recent last):");
            int count = 0;
            for (String log : logs) {
                if (count++ >= 10)
                    break; // Show only most recent 10 logs
                System.out.println("   " + log);
            }

            if (logs.size() > 10) {
                System.out.println("   ... and " + (logs.size() - 10) + " more logs");
            }
        }
    }

    /**
     * Saves user data to file
     */
    private void saveUsersToFile() {
        try {
            FileHandler.saveUsers(users);
        } catch (IOException e) {
            System.out.println("⚠️ Failed to save users: " + e.getMessage());
        }
    }

    /**
     * Displays all users in the system
     */
    private void viewUsers() {
        if (users.isEmpty()) {
            System.out.println("⚠️ No users found.");
        } else {
            System.out.println("📜 Registered Users:");
            users.forEach(user -> System.out.println("   - " + user.getUsername() + " (" + user.getRole() + ")"));
        }
    }

    /**
     * Adds a new user to the system
     * 
     * @param scanner Scanner for user input
     */
    private void addUser(Scanner scanner) {
        System.out.print("👤 Enter new username: ");
        String username = scanner.nextLine();
        System.out.print("🔑 Enter password: ");
        String password = scanner.nextLine();

        // Check password strength using Security utility class
        if (!Security.PasswordHandler.isStrongPassword(password)) {
            System.out.println("⚠️ Password is too weak! It should be at least 8 characters with at least one digit.");
            return;
        }

        for (RegularUser user : users) {
            if (user.getUsername().equals(username)) {
                System.out.println("⚠️ User already exists!");
                return;
            }
        }

        users.add(new RegularUser(username, password));
        FileHandler.logEvent("Admin added new user: " + username);
        System.out.println("✅ User '" + username + "' added successfully.");

        // Save updated user list to file
        saveUsersToFile();
    }

    /**
     * Removes a user from the system
     * 
     * @param scanner Scanner for user input
     */
    private void removeUser(Scanner scanner) {
        System.out.print("❌ Enter username to remove: ");
        String username = scanner.nextLine();

        boolean removed = users.removeIf(user -> user.getUsername().equals(username));
        if (removed) {
            FileHandler.logEvent("Admin removed user: " + username);
            System.out.println("✅ User '" + username + "' removed successfully.");
            // Save updated user list to file
            saveUsersToFile();
        } else {
            System.out.println("⚠️ User not found!");
        }
    }

    /**
     * Adds a new device to the system
     * 
     * @param scanner Scanner for user input
     */
    public void addDevice(Scanner scanner) {
        System.out.println("\n📌 Choose a device to add:");
        System.out.println("1️⃣ Light");
        System.out.println("2️⃣ Fan");
        System.out.println("3️⃣ AC");

        System.out.print("💡 Enter your choice: ");
        int choice;
        try {
            choice = scanner.nextInt();
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌ Invalid input! Please enter a number.");
            scanner.nextLine();
            return;
        }

        ControllableDevice newDevice = null;
        try {
            switch (choice) {
                case 1:
                    lightCount++;
                    newDevice = new Light("Light" + lightCount);
                    break;
                case 2:
                    fanCount++;
                    newDevice = new Fan("Fan" + fanCount);
                    break;
                case 3:
                    acCount++;
                    newDevice = new AC("AC" + acCount);
                    break;
                default:
                    System.out.println("❌ Invalid selection.");
                    return;
            }

            devices.add(newDevice);
            FileHandler.logEvent("Admin added device: " + newDevice.getName());
            System.out.println("✅ " + newDevice.getName() + " added successfully.");
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    /**
     * Removes a device from the system
     * 
     * @param scanner Scanner for user input
     */
    public void removeDevice(Scanner scanner) {
        if (devices.isEmpty()) {
            System.out.println("⚠️ No devices available to remove.");
            return;
        }

        System.out.println("\n📜 Available Devices:");
        for (int i = 0; i < devices.size(); i++) {
            System.out.println("   " + i + ". " + devices.get(i).getName());
        }

        System.out.print("❌ Enter the number of the device to remove: ");
        int choice;
        try {
            choice = scanner.nextInt();
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌ Invalid input! Please enter a valid number.");
            scanner.nextLine();
            return;
        }

        if (choice < 0 || choice >= devices.size()) {
            System.out.println("❌ Invalid selection.");
        } else {
            String deviceName = devices.get(choice).getName();
            FileHandler.logEvent("Admin removed device: " + deviceName);
            System.out.println("✅ " + deviceName + " removed successfully.");
            devices.remove(choice);
        }
    }

    /**
     * Displays all devices in the system
     */
    private void viewDevices() {
        if (devices.isEmpty()) {
            System.out.println("⚠️ No devices added yet.");
        } else {
            System.out.println("📜 Added Devices:");
            for (ControllableDevice device : devices) {
                System.out.println("   - " + device.getName() + " - " + device.getStatus());
            }
        }
    }

    /**
     * Displays energy consumption of all devices
     */
    public void viewEnergyConsumption() {
        if (devices.isEmpty()) {
            System.out.println("⚠️ No devices available.");
            return;
        }

        double totalConsumption = 0;
        System.out.println("\n📊 Energy Consumption Report:");
        for (ControllableDevice device : devices) {
            device.calculateEnergyUsage(); // Ensure usage is updated before display
            System.out.println(
                    "   - " + device.getName() + ": " + String.format("%.2f", device.getTotalEnergyUsed()) + " kWh");
            totalConsumption += device.getTotalEnergyUsed();
        }
        System.out.println("\n🔹 Total Energy Consumption: " + String.format("%.2f", totalConsumption) + " kWh");
    }

    /**
     * Getter method to provide users list
     * 
     * @return list of registered users
     */
    public List<RegularUser> getUsers() {
        return users;
    }

    /**
     * Getter method to provide devices list
     * 
     * @return list of devices
     */
    public List<ControllableDevice> getDevices() {
        return devices;
    }
}