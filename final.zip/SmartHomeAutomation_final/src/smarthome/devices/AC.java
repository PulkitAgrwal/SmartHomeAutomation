package smarthome.devices;

import java.util.Scanner;

/**
 * AC (Air Conditioner) device class that extends ControllableDevice.
 * Allows controlling temperature.
 */
public class AC extends ControllableDevice {
    private static final long serialVersionUID = 1L;

    private int temperature;

    /**
     * Constructor for creating an AC device with name
     * 
     * @param name Name of the AC device
     */
    public AC(String name) {
        super(1.5); // AC has 1.5 kWh consumption
        this.name = name;
        this.temperature = 24; // Default temperature in Celsius
    }

    /**
     * Gets the name of the AC
     * 
     * @return Device name
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * User control method implementation
     * 
     * @param scanner Scanner for user input
     */
    @Override
    public void control(Scanner scanner) {
        System.out.print("❄  Enter temperature (16-30°C): ");
        try {
            int temp = scanner.nextInt();
            scanner.nextLine();
            setTemperature(temp);
        } catch (Exception e) {
            System.out.println("❌  Invalid input! Temperature must be between 16 and 30.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    /**
     * Sets the temperature of the AC
     * 
     * @param temperature Temperature in Celsius (16-30)
     */
    public void setTemperature(int temperature) {
        if (temperature < 16 || temperature > 30) {
            System.out.println("❌  Invalid input! Temperature must be between 16 and 30.");
            return;
        }
        if (isOn) {
            this.temperature = temperature;
            System.out.println(name + " temperature set to " + this.temperature + "°C.");
        } else {
            System.out.println("❌  Cannot adjust temperature. " + name + " is OFF.");
        }
    }

    /**
     * Gets the current status of the AC
     * 
     * @return Status string
     */
    @Override
    public String getStatus() {
        return name + ": " + (isOn ? "ON" : "OFF") + ", Temperature: " + (isOn ? temperature + "°C" : "N/A");
    }
}