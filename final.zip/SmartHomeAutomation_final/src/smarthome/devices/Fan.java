package smarthome.devices;

import java.util.Scanner;

/**
 * Fan device class that extends ControllableDevice.
 * Allows controlling fan speed.
 */
public class Fan extends ControllableDevice {
    private static final long serialVersionUID = 1L;

    private int speed;

    /**
     * Constructor for creating a fan device with name
     * 
     * @param name Name of the fan device
     */
    public Fan(String name) {
        super(0.09); // Fan has 0.09 kWh consumption
        this.name = name;
        this.speed = 1; // Default speed
    }

    /**
     * Gets the name of the fan
     * 
     * @return Device name
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * User control method implementation
     * 
     * @param scanner Scanner for user input
     */
    @Override
    public void control(Scanner scanner) {
        System.out.print("🌪  Enter speed level (1-5): ");
        try {
            int level = scanner.nextInt();
            scanner.nextLine();
            setSpeed(level);
        } catch (Exception e) {
            System.out.println("❌  Invalid input! Speed must be between 1 and 5.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    /**
     * Sets the speed of the fan
     * 
     * @param speed Speed level (1-5)
     */
    public void setSpeed(int speed) {
        if (speed < 1 || speed > 5) {
            System.out.println("❌  Invalid input! Speed must be between 1 and 5.");
            return;
        }
        if (isOn) {
            this.speed = speed;
            System.out.println(name + " speed set to " + this.speed);
        } else {
            System.out.println("❌  Cannot adjust speed. " + name + " is OFF.");
        }
    }

    /**
     * Gets the current status of the fan
     * 
     * @return Status string
     */
    @Override
    public String getStatus() {
        return name + ": " + (isOn ? "ON" : "OFF") + ", Speed: " + (isOn ? speed : "N/A");
    }
}