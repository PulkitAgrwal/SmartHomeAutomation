package smarthome.devices;

import java.util.Scanner;

/**
 * Light device class that extends ControllableDevice.
 * Allows controlling brightness level.
 */
public class Light extends ControllableDevice {
    private static final long serialVersionUID = 1L;

    private int brightness;

    /**
     * Constructor for creating a light device with name
     * 
     * @param name Name of the light device
     */
    public Light(String name) {
        super(0.06); // Light has 0.06 kWh consumption
        this.name = name;
        this.brightness = 100; // Default brightness
    }

    /**
     * Gets the name of the light
     * 
     * @return Device name
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * User control method implementation
     * 
     * @param scanner Scanner for user input
     */
    @Override
    public void control(Scanner scanner) {
        System.out.print("💡 Enter brightness level (1-100): ");
        try {
            int level = scanner.nextInt();
            scanner.nextLine();
            setBrightness(level);
        } catch (Exception e) {
            System.out.println("❌ Invalid input! Brightness must be between 1 and 100.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    /**
     * Sets the brightness level of the light
     * 
     * @param brightness Brightness level (1-100)
     */
    public void setBrightness(int brightness) {
        if (brightness < 1 || brightness > 100) {
            System.out.println("❌ Invalid input! Brightness must be between 1 and 100.");
            return;
        }
        if (isOn) {
            this.brightness = brightness;
            System.out.println(name + " brightness set to " + this.brightness + "%.");
        } else {
            System.out.println("❌ Cannot adjust brightness. " + name + " is OFF.");
        }
    }

    /**
     * Gets the current status of the light
     * 
     * @return Status string
     */
    @Override
    public String getStatus() {
        return name + ": " + (isOn ? "ON" : "OFF") + ", Brightness: " + (isOn ? brightness + "%" : "N/A");
    }
}