package smarthome.devices;

import java.util.Scanner;
import java.io.Serializable;

/**
 * Abstract class for all controllable devices.
 * Defines common functionality and properties for all smart home devices.
 */
public abstract class ControllableDevice implements Serializable {
    private static final long serialVersionUID = 1L;

    protected boolean isOn;
    protected double powerConsumption; // kWh per hour
    protected String name;
    protected long lastTurnedOnTime;
    protected double totalEnergyUsed; // Tracks total energy used

    /**
     * Default constructor with default power consumption
     * Demonstrates constructor overloading
     */
    public ControllableDevice() {
        this(0.1); // Default power consumption
    }

    /**
     * Constructor with specified power consumption
     * 
     * @param powerConsumption Power consumption in kWh
     */
    public ControllableDevice(double powerConsumption) {
        this.powerConsumption = powerConsumption;
        this.isOn = false;
        this.totalEnergyUsed = 0;
    }

    /**
     * Overloaded constructor with name and power consumption
     * 
     * @param name             Name of the device
     * @param powerConsumption Power consumption in kWh
     */
    public ControllableDevice(String name, double powerConsumption) {
        this.name = name;
        this.powerConsumption = powerConsumption;
        this.isOn = false;
        this.totalEnergyUsed = 0;
    }

    /**
     * Turns on the device if it's not already on
     */
    public void turnOn() {
        if (!isOn) {
            isOn = true;
            lastTurnedOnTime = System.currentTimeMillis();
            System.out.println(name + " is now ON.");
        } else {
            System.out.println(name + " is already ON.");
        }
    }

    /**
     * Turns off the device if it's not already off
     * Updates energy usage before turning off
     */
    public void turnOff() {
        if (isOn) {
            isOn = false;
            calculateEnergyUsage(); // Update energy usage before turning off
            System.out.println(name + " is now OFF.");
        } else {
            System.out.println(name + " is already OFF.");
        }
    }

    /**
     * Calculates energy usage since device was turned on
     * Updates totalEnergyUsed and resets timer
     */
    public void calculateEnergyUsage() {
        if (isOn) {
            long elapsedTime = System.currentTimeMillis() - lastTurnedOnTime; // Time in milliseconds
            double hoursUsed = elapsedTime / (1000.0 * 3600.0); // Convert to hours
            totalEnergyUsed += hoursUsed * powerConsumption; // kWh used
            lastTurnedOnTime = System.currentTimeMillis(); // Reset timer
        }
    }

    /**
     * Checks if the device is currently on
     * 
     * @return true if the device is on, false otherwise
     */
    public boolean isOn() {
        return isOn;
    }

    /**
     * Nested class for device status information
     * Demonstrates use of static nested class
     */
    public static class DeviceStatus {
        private final String name;
        private final boolean isOn;
        private final double energy;

        /**
         * Constructor for device status
         * 
         * @param name   Device name
         * @param isOn   On/off status
         * @param energy Energy used
         */
        public DeviceStatus(String name, boolean isOn, double energy) {
            this.name = name;
            this.isOn = isOn;
            this.energy = energy;
        }

        /**
         * String representation of device status
         */
        @Override
        public String toString() {
            return name + ": " + (isOn ? "ON" : "OFF") + ", Energy used: " + String.format("%.2f", energy) + " kWh";
        }
    }

    /**
     * Gets the current device status
     * 
     * @return DeviceStatus object with current status
     */
    public DeviceStatus getDeviceStatus() {
        calculateEnergyUsage(); // Update energy usage
        return new DeviceStatus(name, isOn, totalEnergyUsed);
    }

    /**
     * Gets total energy used by the device
     * Updates calculation before returning
     * 
     * @return Total energy used in kWh
     */
    public double getTotalEnergyUsed() {
        calculateEnergyUsage(); // Update before returning
        return totalEnergyUsed;
    }

    /**
     * Gets the name of the device
     * 
     * @return Device name
     */
    public String getName() {
        return name;
    }

    /**
     * Abstract method to get device status as string
     * 
     * @return Status string
     */
    public abstract String getStatus();

    /**
     * Abstract method to control device via user input
     * 
     * @param scanner Scanner for user input
     */
    public abstract void control(Scanner scanner);
}