package smarthome.devices;

/**
 * Factory class for creating different types of devices.
 * Implements factory pattern for device creation.
 */
public class DeviceFactory {

    /**
     * Inner interface for device suppliers
     * Demonstrates use of nested interface
     */
    public interface DeviceSupplier {
        ControllableDevice createDevice(String name);
    }

    /**
     * Creates a device of the specified type.
     * Demonstrates varargs overloading.
     * 
     * @param type             The type of device to create
     * @param name             The name of the device
     * @param additionalParams Optional additional parameters (not used in this
     *                         implementation)
     * @return The created device
     * @throws IllegalArgumentException if device type is unknown
     */
    public static ControllableDevice createDevice(String type, String name, Object... additionalParams) {
        switch (type.toLowerCase()) {
            case "light":
                return new Light(name);
            case "fan":
                return new Fan(name);
            case "ac":
                return new AC(name);
            default:
                throw new IllegalArgumentException("Unknown device type: " + type);
        }
    }

    /**
     * Overloaded method for creating multiple devices of the same type.
     * 
     * @param type     The type of device to create
     * @param count    Number of devices to create
     * @param baseName Base name for the devices
     * @return Array of created devices
     * @throws IllegalArgumentException if device type is unknown
     */
    public static ControllableDevice[] createDevice(String type, int count, String baseName) {
        ControllableDevice[] devices = new ControllableDevice[count];
        for (int i = 0; i < count; i++) {
            devices[i] = createDevice(type, baseName + (i + 1));
        }
        return devices;
    }
}