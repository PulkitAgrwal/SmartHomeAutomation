package smarthome.main;

import smarthome.auth.Admin;
import smarthome.auth.RegularUser;
import smarthome.automation.ScheduledAutomation;
import smarthome.automation.AutomationThread;
import smarthome.io.FileHandler;
import java.util.Scanner;

/**
 * Main logic for the Smart Home Automation System.
 * Controls the application flow and user interaction.
 */
public class SmartHome {
    private Admin admin = new Admin("admin", "admin123");
    private ScheduledAutomation automation = new ScheduledAutomation();
    private Thread automationThread;

    /**
     * Starts the Smart Home system
     * 
     * @param scanner Scanner for user input
     */
    public void start(Scanner scanner) {
        // Start automation thread
        startAutomationThread();

        boolean running = true;
        while (running) {
            System.out.println("\n=============================");
            System.out.println("📌 Main Menu");
            System.out.println("=============================");
            System.out.println("1️⃣ Login as Admin");
            System.out.println("2️⃣ Login as User");
            System.out.println("3️⃣ Exit");
            System.out.println("=============================");

            System.out.print("💡 Choose an option: ");
            int choice;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (Exception e) {
                System.out.println("❌ Invalid input! Please enter a number.");
                scanner.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    if (admin.login(scanner)) {
                        admin.adminMenu(scanner);
                    } else {
                        System.out.println("❌ Login failed. Please try again.");
                    }
                    break;
                case 2:
                    System.out.print("👤 Enter username: ");
                    String username = scanner.nextLine();
                    RegularUser user = findUser(username);
                    if (user != null && user.login(scanner)) {
                        user.userMenu(scanner, admin.getDevices(), automation);
                    } else {
                        System.out.println("❌ Invalid username or password.");
                    }
                    break;
                case 3:
                    running = false;
                    stopAutomationThread();
                    System.out.println("👋 Exiting Smart Home System. Goodbye!");
                    break;
                default:
                    System.out.println("❌ Invalid choice. Try again.");
            }
        }
    }

    /**
     * Starts the automation thread
     */
    private void startAutomationThread() {
        AutomationThread automationRunnable = new AutomationThread(automation);
        automationThread = new Thread(automationRunnable);
        automationThread.setDaemon(true); // Make it a daemon thread so it exits when main thread exits
        automationThread.start();
    }

    /**
     * Stops the automation thread
     */
    private void stopAutomationThread() {
        if (automationThread != null && automationThread.isAlive()) {
            try {
                // Instead of trying to get the thread's runnable, just interrupt the thread
                automationThread.interrupt();
                automationThread.join(2000); // Wait for thread to finish
            } catch (InterruptedException e) {
                System.out.println("⚠️ Error stopping automation thread: " + e.getMessage());
                FileHandler.logEvent("Error stopping automation thread: " + e.getMessage());
            }
        }
    }

    /**
     * Finds a user by username
     * 
     * @param username Username to search for
     * @return RegularUser if found, null otherwise
     */
    private RegularUser findUser(String username) {
        for (RegularUser user : admin.getUsers()) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }
}