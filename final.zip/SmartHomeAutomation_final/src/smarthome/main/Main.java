package smarthome.main;

import java.util.Scanner;
import smarthome.io.FileHandler;

/**
 * Entry point for the Smart Home Automation System.
 */
public class Main {
    /**
     * Main method - entry point of the application
     *
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        System.out.println("🏠  Starting Smart Home Automation System...");
        FileHandler.logEvent("System startup");

        Scanner scanner = new Scanner(System.in);
        SmartHome smartHome = new SmartHome();

        try {
            smartHome.start(scanner);
        } catch (Exception e) {
            System.out.println("❌  Fatal error: " + e.getMessage());
            e.printStackTrace();
            FileHandler.logEvent("System crashed: " + e.getMessage());
        } finally {
            scanner.close();
            System.out.println("👋  Smart Home System shutdown complete.");
            FileHandler.logEvent("System shutdown");
        }
    }
}
