package smarthome.exceptions;

/**
 * Custom exception for Smart Home system.
 * Handles device control and automation exceptions.
 */
public class SmartHomeException extends Exception {
    private static final long serialVersionUID = 1L;

    /**
     * Constructor with message
     *
     * @param message Error message
     */
    public SmartHomeException(String message) {
        super(message);
    }

    /**
     * Constructor with message and cause
     *
     * @param message Error message
     * @param cause Cause of the exception
     */
    public SmartHomeException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Nested class for device control exceptions.
     * Demonstrates nested exception classes.
     */
    public static class DeviceControlException extends SmartHomeException {
        private static final long serialVersionUID = 1L;
        private String deviceName;

        /**
         * Constructor for device control exception
         *
         * @param deviceName Name of the device
         * @param message Error message
         */
        public DeviceControlException(String deviceName, String message) {
            super("Error controlling device " + deviceName + ": " + message);
            this.deviceName = deviceName;
        }

        /**
         * Gets the name of the device that caused the exception
         *
         * @return Device name
         */
        public String getDeviceName() {
            return deviceName;
        }
    }

    /**
     * Nested class for automation exceptions.
     */
    public static class AutomationException extends SmartHomeException {
        private static final long serialVersionUID = 1L;

        /**
         * Constructor for automation exception
         *
         * @param message Error message
         */
        public AutomationException(String message) {
            super("Automation error: " + message);
        }
    }
}
