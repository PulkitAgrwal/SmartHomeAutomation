package smarthome.automation;

import smarthome.io.FileHandler;

/**
 * Thread implementation for running automation tasks.
 * Implements Runnable interface for multithreading.
 */
public class AutomationThread implements Runnable {
    private ScheduledAutomation scheduler;
    private volatile boolean running = true;

    /**
     * Constructor for automation thread
     * 
     * @param scheduler The scheduler to use for executing tasks
     */
    public AutomationThread(ScheduledAutomation scheduler) {
        this.scheduler = scheduler;
    }

    /**
     * Run method that continuously checks and executes scheduled tasks
     */
    @Override
    public void run() {
        System.out.println("🔄 Automation thread started...");
        FileHandler.logEvent("Automation thread started");

        try {
            while (running && !Thread.currentThread().isInterrupted()) {
                // Execute scheduled tasks
                int executed = scheduler.executeScheduledTasks();
                if (executed > 0) {
                    System.out.println("✅ Executed " + executed + " scheduled tasks.");
                }

                // Sleep for 1 second
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            // Handle interruption gracefully
            System.out.println("⚠️ Automation thread interrupted");
            FileHandler.logEvent("Automation thread interrupted");
            // Reset interrupt status
            Thread.currentThread().interrupt();
        }

        System.out.println("🛑 Automation thread stopped.");
        FileHandler.logEvent("Automation thread stopped");
    }

    /**
     * Stops the automation thread
     */
    public void stop() {
        running = false;
    }
}