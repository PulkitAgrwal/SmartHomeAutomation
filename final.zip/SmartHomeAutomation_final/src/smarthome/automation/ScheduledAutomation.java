package smarthome.automation;

import smarthome.devices.*;
import smarthome.io.FileHandler;
import java.util.*;

/**
 * Schedules automated tasks for smart home devices.
 * Allows users to schedule actions to be performed at specified times.
 */
public class ScheduledAutomation {
    private List<ScheduledTask> scheduledTasks = new ArrayList<>();

    /**
     * Creates a new scheduled automation task
     *
     * @param scanner Scanner for user input
     * @param devices List of available devices
     */
    public void scheduleAutomation(Scanner scanner, List<ControllableDevice> devices) {
        if (devices.isEmpty()) {
            System.out.println("⚠  No devices available for automation.");
            return;
        }

        // 1️⃣  Show available devices with proper names
        System.out.println("\n📜  Select a Device to Automate:");
        for (int i = 0; i < devices.size(); i++) {
            System.out.println("   " + i + ". " + devices.get(i).getName());
        }

        // 2️⃣  Ask user to select a device
        System.out.print("💡  Enter device number: ");
        int choice;
        try {
            choice = scanner.nextInt();
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌  Invalid input! Please enter a number.");
            scanner.nextLine();
            return;
        }

        if (choice < 0 || choice >= devices.size()) {
            System.out.println("❌  Invalid selection.");
            return;
        }

        ControllableDevice device = devices.get(choice);

        // 3️⃣  Ask for delay in hours
        System.out.print("⏳  Enter delay time in hours (e.g., 1.5 for 1 hour 30 minutes): ");
        double delayInHours;
        try {
            delayInHours = scanner.nextDouble();
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌  Invalid input! Please enter a decimal number.");
            scanner.nextLine();
            return;
        }

        int delayInSeconds = (int) (delayInHours * 3600); // Convert hours to seconds

        // 4️⃣  Ask user for ON/OFF action
        System.out.println("\n🔘  Select Action: 1️⃣  Turn ON | 2️⃣  Turn OFF");
        int actionChoice;
        try {
            actionChoice = scanner.nextInt();
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌  Invalid input! Please enter a valid number.");
            scanner.nextLine();
            return;
        }

        String action = "";
        if (actionChoice == 1) {
            action = "ON";
        } else if (actionChoice == 2) {
            action = "OFF";
        } else {
            System.out.println("❌  Invalid action.");
            return;
        }

        // 5️⃣  If turning ON, ask for additional adjustments
        if (action.equals("ON")) {
            if (device instanceof Light) {
                System.out.print("💡  Enter Brightness Level (0-100): ");
                int brightness = scanner.nextInt();
                scanner.nextLine();
                action += "|BRIGHTNESS:" + brightness;
            } else if (device instanceof Fan) {
                System.out.print("🌪  Enter Speed Level (1-5): ");
                int speed = scanner.nextInt();
                scanner.nextLine();
                action += "|SPEED:" + speed;
            } else if (device instanceof AC) {
                System.out.print("❄  Enter Temperature (16-30°C): ");
                int temp = scanner.nextInt();
                scanner.nextLine();
                action += "|TEMPERATURE:" + temp;
            }
        }

        // 6️⃣  Schedule the task
        ScheduledTask task = new ScheduledTask(device, delayInSeconds, action);
        scheduledTasks.add(task);

        // Log the scheduled action
        FileHandler.logEvent("Scheduled task for " + device.getName() + " in " + delayInSeconds + " seconds.");
        System.out.println("✅  Automation scheduled successfully for " + device.getName());
    }

    /**
     * Executes scheduled tasks that are due
     * Called by the automation thread
     *
     * @return Number of tasks executed
     */
    public int executeScheduledTasks() {
        int executed = 0;
        Iterator<ScheduledTask> iterator = scheduledTasks.iterator();
        while (iterator.hasNext()) {
            ScheduledTask task = iterator.next();
            if (task.execute()) {
                iterator.remove();
                executed++;
            }
        }
        return executed;
    }

    /**
     * Gets the count of pending tasks
     *
     * @return Number of pending tasks
     */
    public int getPendingTaskCount() {
        return scheduledTasks.size();
    }
}
