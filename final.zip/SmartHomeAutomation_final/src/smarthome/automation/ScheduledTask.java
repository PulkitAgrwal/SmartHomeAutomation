package smarthome.automation;

import smarthome.devices.*;
import smarthome.io.FileHandler;

/**
 * Represents a scheduled task for a device.
 * Contains the device, execution time, and action to perform.
 */
public class ScheduledTask {
    private ControllableDevice device;
    private long executionTime;
    private String action;

    /**
     * Constructor for creating a scheduled task
     *
     * @param device Device to control
     * @param delayInSeconds Delay before execution in seconds
     * @param action Action to perform
     */
    public ScheduledTask(ControllableDevice device, int delayInSeconds, String action) {
        this.device = device;
        this.executionTime = System.currentTimeMillis() + (delayInSeconds * 1000L);
        this.action = action;
    }

    /**
     * Executes the scheduled task if it's time
     *
     * @return true if task was executed, false if not yet time
     */
    public boolean execute() {
        if (System.currentTimeMillis() >= executionTime) {
            System.out.println("⏳  Executing scheduled action for " + device.getName());
            FileHandler.logEvent("Executing scheduled task for " + device.getName());

            String[] actions = action.split("\\|");

            for (String act : actions) {
                try {
                    if (act.equals("ON")) {
                        device.turnOn();
                    } else if (act.equals("OFF")) {
                        device.turnOff();
                    } else if (act.startsWith("BRIGHTNESS:")) {
                        int brightness = Integer.parseInt(act.split(":")[1]);
                        if (device instanceof Light) {
                            ((Light) device).setBrightness(brightness);
                        }
                    } else if (act.startsWith("SPEED:")) {
                        int speed = Integer.parseInt(act.split(":")[1]);
                        if (device instanceof Fan) {
                            ((Fan) device).setSpeed(speed);
                        }
                    } else if (act.startsWith("TEMPERATURE:")) {
                        int temp = Integer.parseInt(act.split(":")[1]);
                        if (device instanceof AC) {
                            ((AC) device).setTemperature(temp);
                        }
                    } else {
                        System.out.println("❌  Unknown action: " + act);
                    }
                } catch (Exception e) {
                    System.out.println("❌  Error executing action: " + e.getMessage());
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Gets the remaining time until execution
     *
     * @return Time in milliseconds until execution
     */
    public long getTimeRemaining() {
        return Math.max(0, executionTime - System.currentTimeMillis());
    }

    /**
     * Gets information about the scheduled task
     *
     * @return String representation of the task
     */
    public String getInfo() {
        long remainingSeconds = getTimeRemaining() / 1000;
        return "Task for " + device.getName() + ": " + action +
               " (Executes in " + formatTime(remainingSeconds) + ")";
    }

    /**
     * Formats time in seconds to a readable format
     *
     * @param seconds Time in seconds
     * @return Formatted time string
     */
    private String formatTime(long seconds) {
        if (seconds < 60) {
            return seconds + " seconds";
        } else if (seconds < 3600) {
            return (seconds / 60) + " minutes " + (seconds % 60) + " seconds";
        } else {
            long hours = seconds / 3600;
            long minutes = (seconds % 3600) / 60;
            return hours + " hours " + minutes + " minutes";
        }
    }
}
