package smarthome.automation;

/**
 * Interface for automation features.
 * Defines method for triggering events.
 */
public interface Automation {
    
    /**
     * Triggers an automation event
     * 
     * @param event The event to trigger
     */
    void triggerEvent(String event);
}