package smarthome.io;

import smarthome.auth.RegularUser;
import smarthome.devices.*;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Handles file I/O operations for the Smart Home system.
 * Saves and loads user and device data for persistence.
 */
public class FileHandler {
    private static final String USERS_FILE = "users.dat";
    private static final String LOGS_FILE = "system_logs.txt";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * Saves user data to file.
     * 
     * @param users List of users to save
     * @throws IOException If an I/O error occurs
     */
    public static void saveUsers(List<RegularUser> users) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(USERS_FILE))) {
            oos.writeObject(users);
            System.out.println("✅ User data saved successfully.");
        } catch (IOException e) {
            System.out.println("❌ Error saving user data: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Loads user data from file.
     * 
     * @return List of loaded users
     * @throws IOException            If an I/O error occurs
     * @throws ClassNotFoundException If class of serialized object cannot be found
     */
    @SuppressWarnings("unchecked")
    public static List<RegularUser> loadUsers() throws IOException, ClassNotFoundException {
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(USERS_FILE))) {
            return (List<RegularUser>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❌ Error loading user data: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Logs a system event to file.
     * 
     * @param message The event message to log
     */
    public static void logEvent(String message) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOGS_FILE, true))) {
            writer.println(DATE_FORMAT.format(new Date()) + " - " + message);
        } catch (IOException e) {
            System.out.println("⚠️ Warning: Could not write to log file: " + e.getMessage());
        }
    }

    /**
     * Reads and returns system logs.
     * 
     * @return List of log entries
     */
    public static List<String> readLogs() {
        List<String> logs = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(LOGS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                logs.add(line);
            }
        } catch (IOException e) {
            System.out.println("⚠️ Warning: Could not read log file: " + e.getMessage());
        }

        return logs;
    }

    /**
     * Exports energy consumption report to CSV file.
     * 
     * @param devices  List of devices
     * @param filename Output filename
     * @return true if export successful, false otherwise
     */
    public static boolean exportEnergyReportToCSV(List<ControllableDevice> devices, String filename) {
        if (devices == null || devices.isEmpty()) {
            return false;
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            // Write CSV header
            writer.println("Device,Status,Energy Consumption (kWh)");

            // Write device data
            for (ControllableDevice device : devices) {
                device.calculateEnergyUsage(); // Update energy usage
                writer.println(device.getName() + "," +
                        (device.isOn() ? "ON" : "OFF") + "," +
                        String.format("%.2f", device.getTotalEnergyUsed()));
            }

            System.out.println("✅ Energy report exported to " + filename);
            return true;
        } catch (IOException e) {
            System.out.println("❌ Error exporting energy report: " + e.getMessage());
            return false;
        }
    }
}